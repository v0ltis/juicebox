fitler_FR_in = ['va te faire','va te faire voir','va te faire foutre','va te faire enculé','enculé','enculer'
'tg','ta mère','nique','bite',"pute","salope","connard","cul","abrutit","encule","chatte","bitch",'bâtard',
"biatch",'branleur','couilles','chargasse','con','conasse','connarde',"ducon",'enfoiré','fdp','ta gueule',
'ta guele','ta geule','garce',"ta race",'fumier','gland','kikou','noob','tapette','mauviette','merdeux',
'michto','minus','moins-que-rien','moins que rien','mollusque','naze','sa mère','sac à merde','pd',
"pédé","plouc",'salop','zguègue','trou de cul',"trou d'uc",'trou du cul',"trou de bal","trouduc",
'tafiole','tarlouze','ptn','fk ','fuck',' fk']

fitler_FR_emoji = ['🖕',':middle_finger:']
fitler_FR_not = ['tapette à ','connerie']
fitler_FR_and = []
fitler_FR_or = []

#https://fr.wiktionary.org/wiki/Cat%C3%A9gorie:Insultes_en_fran%C3%A7ais
#http://www.topito.com/top-insultes-preferees-francais
#https://en.wiktionary.org/wiki/Category:English_offensive_terms

shit = ['merde','shit','Scheiße','chisse','chier','chiant']

react_with_number = (['-0', '-1', '-2', '-3', '-4', '-5', '-6', '-7', '-8', '-9'],
	['0-', '1-', '2-', '3-', '4-', '5-', '6-', '7-', '8-', '9-'])

reactions_numbers = ['0⃣','1⃣','2⃣','3⃣','4⃣','5⃣','6⃣','7⃣','8⃣','9⃣']