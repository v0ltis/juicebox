# JuiceBot3.7
 Juicy's rewrite for python 3.7.4 with latest discord.py version
